# AI-Powered Customer Sentiment Analysis

A GenAI + Data Science project that analyzes customer reviews, classifies sentiment, explains the result, summarizes feedback, and answers natural-language questions about a review dataset.

## Features
- GenAI sentiment classification: positive / neutral / negative
- Confidence score, key phrases, aspect, and explanation
- Data-science dashboard using Pandas and Plotly
- AI-generated customer feedback summary
- Natural-language Q&A over dataset statistics and review samples
- Streamlit web interface

## Tech stack
- Python
- Streamlit
- Pandas
- Plotly
- Groq API with `openai/gpt-oss-20b`

## Setup

1. Create and activate a virtual environment.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Create a `.env` file from `.env.example` and add your Groq API key.
4. Run:

```bash
streamlit run app.py
```

## Important
Never commit `.env` or an API key to GitHub.

The included CSV is starter data for development. Before final submission, replace it with the dataset used for the final experiment and record the actual test results and metrics.
