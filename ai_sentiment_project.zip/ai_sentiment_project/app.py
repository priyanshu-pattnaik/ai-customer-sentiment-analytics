import os
import json
import pandas as pd
import plotly.express as px
import streamlit as st
from dotenv import load_dotenv
from groq import Groq

load_dotenv()

MODEL = "openai/gpt-oss-20b"
DATA_PATH = "data/reviews.csv"

st.set_page_config(page_title="AI Sentiment Insights", page_icon="💬", layout="wide")

@st.cache_data

def load_data():
    df = pd.read_csv(DATA_PATH)
    return df


def get_client():
    key = os.getenv("GROQ_API_KEY")
    if not key:
        raise RuntimeError("GROQ_API_KEY is missing. Add it to your .env file.")
    return Groq(api_key=key)


def analyze_review(review):
    client = get_client()
    schema = {
        "type": "json_schema",
        "json_schema": {
            "name": "sentiment_result",
            "strict": True,
            "schema": {
                "type": "object",
                "properties": {
                    "sentiment": {"type": "string", "enum": ["positive", "negative", "neutral"]},
                    "confidence": {"type": "number", "minimum": 0, "maximum": 1},
                    "key_phrases": {"type": "array", "items": {"type": "string"}},
                    "explanation": {"type": "string"},
                    "aspect": {"type": "string"}
                },
                "required": ["sentiment", "confidence", "key_phrases", "explanation", "aspect"],
                "additionalProperties": False
            }
        }
    }
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": "You are a sentiment-analysis assistant for customer reviews. Classify the review as positive, negative, or neutral. Base the classification only on the review. Identify the main aspect and explain the decision briefly."},
            {"role": "user", "content": review}
        ],
        response_format=schema,
        temperature=0,
        max_completion_tokens=500,
        include_reasoning=False,
    )
    return json.loads(response.choices[0].message.content)


def summarize_reviews(df):
    client = get_client()
    sample = df["review"].head(80).tolist()
    context = "\n".join(f"- {x}" for x in sample)
    prompt = f"""Analyze these customer reviews as a data-science assistant.\n\nREVIEWS:\n{context}\n\nReturn a concise business summary with: overall_sentiment, top_positive_points, top_negative_points, common_themes, and recommendations. Do not invent information not supported by the reviews."""
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": "You summarize customer feedback using only the supplied reviews."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.2,
        max_completion_tokens=900,
        include_reasoning=False,
    )
    return response.choices[0].message.content


def ask_dataset(df, question):
    client = get_client()
    stats = {
        "rows": len(df),
        "columns": list(df.columns),
        "products": df["product"].value_counts().to_dict(),
        "sentiment_counts": df["sentiment"].value_counts().to_dict() if "sentiment" in df.columns else {},
        "average_rating": round(float(df["rating"].mean()), 2) if "rating" in df.columns else None,
    }
    sample = df[["product", "review"]].head(50).to_dict(orient="records")
    prompt = f"Dataset statistics: {json.dumps(stats)}\nSample reviews: {json.dumps(sample)}\n\nQuestion: {question}\nAnswer using only the supplied dataset information. If the data is insufficient, say so."
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": "You are a data analyst answering questions about a customer-review dataset. Be concise and evidence-based."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.2,
        max_completion_tokens=700,
        include_reasoning=False,
    )
    return response.choices[0].message.content


st.title("💬 AI-Powered Customer Sentiment Analysis")
st.caption("Generative AI + Data Science • NLP sentiment classification and customer-review insights")

df = load_data()

with st.sidebar:
    st.header("Project")
    st.write("Analyze customer reviews with a GenAI model and explore the results with data-science visualizations.")
    st.divider()
    st.write(f"**Reviews:** {len(df)}")
    st.write(f"**Products:** {df['product'].nunique()}")
    st.write(f"**Model:** {MODEL}")

if "sentiment" not in df.columns:
    df["sentiment"] = "Not analyzed"

# KPI row
c1, c2, c3, c4 = st.columns(4)
c1.metric("Total Reviews", len(df))
c2.metric("Average Rating", f"{df['rating'].mean():.2f}/5")
c3.metric("Products", df["product"].nunique())
c4.metric("Analyzed Reviews", int((df["sentiment"] != "Not analyzed").sum()))

st.divider()

tab1, tab2, tab3, tab4 = st.tabs(["🔎 Analyze Review", "📊 Data Science Dashboard", "🧠 GenAI Insights", "💬 Ask the Dataset"])

with tab1:
    st.subheader("Analyze one customer review")
    review = st.text_area("Enter a review", placeholder="Example: The product quality is excellent, but delivery was slower than expected.", height=130)
    if st.button("Analyze Sentiment", type="primary"):
        if not review.strip():
            st.warning("Please enter a review.")
        else:
            try:
                result = analyze_review(review.strip())
                st.success(f"Sentiment: {result['sentiment'].upper()}")
                a, b, c = st.columns(3)
                a.metric("Sentiment", result["sentiment"].title())
                b.metric("Confidence", f"{result['confidence']:.0%}")
                c.metric("Main Aspect", result["aspect"])
                st.write("**Why?**", result["explanation"])
                st.write("**Key phrases:**", ", ".join(result["key_phrases"]))
            except Exception as e:
                st.error(f"API error: {e}")

with tab2:
    st.subheader("Customer feedback dashboard")
    col1, col2 = st.columns(2)
    with col1:
        fig = px.histogram(df, x="rating", nbins=5, title="Rating Distribution")
        st.plotly_chart(fig, use_container_width=True)
    with col2:
        fig = px.bar(df["product"].value_counts().reset_index(), x="product", y="count", title="Reviews by Product")
        st.plotly_chart(fig, use_container_width=True)
    st.dataframe(df, use_container_width=True, hide_index=True)

with tab3:
    st.subheader("Generate insights from the reviews")
    if st.button("Generate AI Summary", type="primary"):
        try:
            with st.spinner("Generating insights..."):
                summary = summarize_reviews(df)
            st.markdown(summary)
        except Exception as e:
            st.error(f"API error: {e}")

with tab4:
    st.subheader("Ask questions about the dataset")
    question = st.text_input("Your question", placeholder="What do customers complain about most?")
    if st.button("Ask AI"):
        if not question.strip():
            st.warning("Enter a question first.")
        else:
            try:
                with st.spinner("Analyzing dataset..."):
                    answer = ask_dataset(df, question.strip())
                st.markdown(answer)
            except Exception as e:
                st.error(f"API error: {e}")

st.divider()
st.caption("Capstone project prototype — actual evaluation metrics will be measured after testing.")
